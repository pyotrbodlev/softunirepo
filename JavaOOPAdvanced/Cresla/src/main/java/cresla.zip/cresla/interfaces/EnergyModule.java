package cresla.interfaces;

public interface EnergyModule extends Module {
    int getEnergyOutput();
}
