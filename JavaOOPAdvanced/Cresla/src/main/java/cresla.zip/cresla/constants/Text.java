package cresla.constants;

public final class Text {
    public static final String REACTOR_CREATED_SUCCESS = "Created %s Reactor - %d";
    public static final String REACTOR_CREATED_ERROR = "INVALID REACTOR";
    public static final String MODULE_CREATED_SUCCESSFUL = "Added %s - %d to Reactor - %d";
}
