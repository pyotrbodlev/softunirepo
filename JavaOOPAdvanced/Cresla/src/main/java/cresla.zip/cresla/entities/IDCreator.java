package cresla.entities;

public class IDCreator {
    public static int id = 0;
}
