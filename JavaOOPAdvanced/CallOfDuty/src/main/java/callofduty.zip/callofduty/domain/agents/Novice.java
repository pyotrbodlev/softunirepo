package callofduty.domain.agents;

public class Novice extends BaseAgent {
    public Novice(String id, String name) {
        super(id, name);
    }
}
