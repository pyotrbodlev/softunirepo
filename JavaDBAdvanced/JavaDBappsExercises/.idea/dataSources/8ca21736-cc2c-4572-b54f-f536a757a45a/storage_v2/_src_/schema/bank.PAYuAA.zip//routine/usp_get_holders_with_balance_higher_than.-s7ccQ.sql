create
    definer = root@localhost procedure usp_get_holders_with_balance_higher_than(IN number decimal(13, 4))
BEGIN
	SELECT ah.first_name, ah.last_name 
    FROM `account_holders` ah 
    JOIN (
		SELECT ac.id AS `accaunt_id`, ah.id AS `holder_id`, ah.first_name, ah.last_name, SUM(balance) AS sum_balance
		FROM `account_holders` ah 
		JOIN accounts ac
		ON ac.`account_holder_id` = ah.id
		GROUP BY ac.`account_holder_id`
    ) AS `result`
    ON result.holder_id = ah.id
    WHERE sum_balance > number
    ORDER BY  accaunt_id , ah.first_name DESC, ah.last_name;
END;

