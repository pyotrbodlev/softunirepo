create
    definer = root@localhost procedure usp_get_employees_by_salary_level(IN level_of_salary varchar(20))
BEGIN 
	SELECT first_name, last_name FROM employees
    WHERE 
    (
		CASE WHEN level_of_salary LIKE 'High' THEN salary > 50000
			WHEN level_of_salary LIKE 'Average' THEN (salary >= 30000 AND salary <= 50000)
            WHEN level_of_salary LIKE 'Low' THEN salary < 30000
            END
    )
    ORDER BY first_name DESC, last_name DESC;
END;

