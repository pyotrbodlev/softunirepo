create
    definer = root@localhost function ufn_get_salary_level(salary_expected int) returns varchar(20)
BEGIN 
	DECLARE result VARCHAR(20) DEFAULT '';
	SET result = (CASE WHEN salary_expected < 30000 THEN 'Low'
		WHEN salary_expected >= 30000 AND salary_expected <= 50000 THEN 'Average'
		WHEN salary_expected > 50000 THEN 'High' ELSE '' END);
    RETURN result;
END;

