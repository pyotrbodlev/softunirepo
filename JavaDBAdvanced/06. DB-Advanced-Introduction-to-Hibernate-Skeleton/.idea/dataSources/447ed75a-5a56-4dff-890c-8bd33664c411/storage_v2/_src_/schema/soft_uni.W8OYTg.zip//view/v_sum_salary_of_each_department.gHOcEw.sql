create view v_sum_salary_of_each_department as
select `soft_uni`.`employees`.`department_id` AS `department_id`,
       sum(`soft_uni`.`employees`.`salary`)   AS `SUM(salary)`
from `soft_uni`.`employees`
group by `soft_uni`.`employees`.`department_id`;

